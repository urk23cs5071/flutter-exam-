import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: FruitPage(),
    ));

class FruitPage extends StatelessWidget {
  const FruitPage({super.key});

  final fruits = const [
    ['Apple', '₹180.00', 'assets/apple.png'],
    ['Orange', '₹100.00', 'assets/orange.png'],
    ['Mango', '₹70.00', 'assets/mango.png'],
    ['Pomegranate', '₹250.00', 'assets/pomegranate.png'],
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Custom List View'),
        centerTitle: true,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(10),
        itemCount: fruits.length,
        itemBuilder: (context, i) => Card(
          child: ListTile(
            leading: Image.asset(
              fruits[i][2],
              width: 75,
              height: 75,
              fit: BoxFit.cover,
            ),
            title: Text(
              fruits[i][0],
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: Text(fruits[i][1]),
            trailing: ElevatedButton(
              onPressed: () {},
              child: const Text('Buy'),
            ),
          ),
        ),
      ),
    );
  }
}
