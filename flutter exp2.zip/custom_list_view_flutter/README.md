# Custom List View – Flutter Experiment

A small fruit shopping list built with Flutter.

## Included
- `lib/main.dart` – simplified ListView.builder program
- `assets/` – four sample fruit images
- `pubspec.yaml` – Flutter project dependencies and asset setup

## Run the project
1. Extract the ZIP file.
2. Open the `custom_list_view_flutter` folder in VS Code or Android Studio.
3. Open a terminal in this folder and run:

   ```bash
   flutter create .
   flutter pub get
   flutter run
   ```

   `flutter create .` generates the platform folders (Android, Windows, etc.) for your installed Flutter SDK. If those folders already exist, you can skip that command.

## Note
The Buy button is a demonstration button and currently has no action.
